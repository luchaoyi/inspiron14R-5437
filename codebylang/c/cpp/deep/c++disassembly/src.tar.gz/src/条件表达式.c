#include<stdio.h>
int main()
{
	int i,j,l,k=8;

	i= k==5? 5:6;
	j= k==5? 4:10;
	l= k<=8? 4:10;
	/*6:        i= k==5? 5:6;
0040102F 33 C0                xor         eax,eax
00401031 83 7D F0 05          cmp         dword ptr [ebp-10h],5
00401035 0F 95 C0             setne       al;  ZF=0 ,al=1,zf=1,al=0
00401038 83 C0 05             add         eax,5
0040103B 89 45 FC             mov         dword ptr [ebp-4],eax
7:        j= k==5? 4:10;
0040103E 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
00401041 83 E9 05             sub         ecx,5
00401044 F7 D9                neg         ecx �Բ�����OPRD����ȡ������,Ȼ�󽫽���ͻ�OPRD.ȡ������Ҳ�����󲹲���,����s ��һ�������෴���Ĳ���.
00401046 1B C9                sbb         ecx,ecx
00401048 83 E1 06             and         ecx,6
0040104B 83 C1 04             add         ecx,4
0040104E 89 4D F8             mov         dword ptr [ebp-8],ecx
8:        l= k<=8? 4:10;
00401051 33 D2                xor         edx,edx
00401053 83 7D F0 08          cmp         dword ptr [ebp-10h],8
00401057 0F 9F C2             setg        dl
0040105A 4A                   dec         edx
0040105B 83 E2 FA             and         edx,0FAh
0040105E 83 C2 0A             add         edx,0Ah
00401061 89 55 F4             mov         dword ptr [ebp-0Ch],edx
*/
	
}