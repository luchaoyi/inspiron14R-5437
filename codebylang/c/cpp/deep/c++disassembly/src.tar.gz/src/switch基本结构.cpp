#include<iostream>
using namespace std;

int main()
{
	int i,j;
	scanf("%d",&i);
	switch (i)
	{
	case 1:j=1;break;
	case 2:j=2;break;
	case 3:j=3;break;
	case 4:j=4;break;
	case 5:j=5;break;
	case 6:j=6;break;
	case 7:j=7;break;
		
/*
�ṹ1�����Խṹ
00401059 8B 4D FC             mov         ecx,dword ptr [ebp-4]
0040105C 89 4D F4             mov         dword ptr [ebp-0Ch],ecx
0040105F 8B 55 F4             mov         edx,dword ptr [ebp-0Ch]
;edx=i
00401062 83 EA 01             sub         edx,1
;edx=i-1
00401065 89 55 F4             mov         dword ptr [ebp-0Ch],edx
;ebp-0ch=i-1
00401068 83 7D F4 06          cmp         dword ptr [ebp-0Ch],6 7-1=6 case 7:�����±�Ϊ6
0040106C 77 47                ja          $L7361+7 (004010b5);>6 Ϊ����case
;<6,4010c8hΪ�����׵�ַ �����ת
0040106E 8B 45 F4             mov         eax,dword ptr [ebp-0Ch]
00401071 FF 24 85 C8 10 40 00 jmp         dword ptr [eax*4+4010C8h]
10:       case 1:j=1;break;
00401078 C7 45 F8 01 00 00 00 mov         dword ptr [ebp-8],1
0040107F EB 34                jmp         $L7361+7 (004010b5)
11:       case 2:j=2;break;
00401081 C7 45 F8 02 00 00 00 mov         dword ptr [ebp-8],2
00401088 EB 2B                jmp         $L7361+7 (004010b5)
12:       case 3:j=3;break;
0040108A C7 45 F8 03 00 00 00 mov         dword ptr [ebp-8],3
00401091 EB 22                jmp         $L7361+7 (004010b5)
13:       case 4:j=4;break;
00401093 C7 45 F8 04 00 00 00 mov         dword ptr [ebp-8],4
0040109A EB 19                jmp         $L7361+7 (004010b5)
14:       case 5:j=5;break;
0040109C C7 45 F8 05 00 00 00 mov         dword ptr [ebp-8],5
004010A3 EB 10                jmp         $L7361+7 (004010b5)
15:       case 6:j=6;break;
004010A5 C7 45 F8 06 00 00 00 mov         dword ptr [ebp-8],6
004010AC EB 07                jmp         $L7361+7 (004010b5)
16:       case 7:j=7;break;
004010AE C7 45 F8 07 00 00 00 mov         dword ptr [ebp-8],7

*/
	}
		switch (i)
	{
	case 1:j=1;break;
	case 2:j=2;break;
	case 3:j=3;break;
	case 4:j=4;break;
	case 5:j=5;break;
	case 6:j=6;break;
	case 255:j=7;break;
		/*
		     switch (i)
57:       {
004010B5 8B 4D FC             mov         ecx,dword ptr [ebp-4]
004010B8 89 4D F0             mov         dword ptr [ebp-10h],ecx
004010BB 8B 55 F0             mov         edx,dword ptr [ebp-10h]
004010BE 83 EA 01             sub         edx,1

004010C1 89 55 F0             mov         dword ptr [ebp-10h],edx
004010C4 81 7D F0 FE 00 00 00 cmp         dword ptr [ebp-10h],0FEh
//�����Ƚ�255���������������
004010CB 77 4F                ja          $L7373+7 (0040111c)
004010CD 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
004010D0 33 C0                xor         eax,eax
004010D2 8A 81 6B 11 40 00    mov         al,byte ptr  (0040116b)[ecx]
004010D8 FF 24 85 4B 11 40 00 jmp         dword ptr [eax*4+40114Bh]
58:       case 1:j=1;break;
004010DF C7 45 F8 01 00 00 00 mov         dword ptr [ebp-8],1
004010E6 EB 34                jmp         $L7373+7 (0040111c)
59:       case 2:j=2;break;
004010E8 C7 45 F8 02 00 00 00 mov         dword ptr [ebp-8],2
004010EF EB 2B                jmp         $L7373+7 (0040111c)
60:       case 3:j=3;break;
004010F1 C7 45 F8 03 00 00 00 mov         dword ptr [ebp-8],3
004010F8 EB 22                jmp         $L7373+7 (0040111c)
61:       case 4:j=4;break;
004010FA C7 45 F8 04 00 00 00 mov         dword ptr [ebp-8],4
00401101 EB 19                jmp         $L7373+7 (0040111c)
62:       case 5:j=5;break;
00401103 C7 45 F8 05 00 00 00 mov         dword ptr [ebp-8],5
0040110A EB 10                jmp         $L7373+7 (0040111c)
63:       case 6:j=6;break;
0040110C C7 45 F8 06 00 00 00 mov         dword ptr [ebp-8],6
00401113 EB 07                jmp         $L7373+7 (0040111c)
64:       case 255:j=7;break;
00401115 C7 45 F8 07 00 00 00 mov         dword ptr [ebp-8],7
*/
	}
				switch (i)
	{
	case 2:j=1;break;
	case 3:j=2;break;
	case 8:j=3;break;
	case 10:j=4;break;
	case 35:j=5;break;
	case 37:j=6;break;
	case 666:j=7;break;


/*
�������ṹ
0040111C 8B 55 FC             mov         edx,dword ptr [ebp-4]
0040111F 89 55 EC             mov         dword ptr [ebp-14h],edx
00401122 83 7D EC 0A          cmp         dword ptr [ebp-14h],0Ah
00401126 7F 1A                jg          $L7373+2Dh (00401142)
00401128 83 7D EC 0A          cmp         dword ptr [ebp-14h],0Ah
0040112C 74 46                je          $L7373+5Fh (00401174)
0040112E 83 7D EC 02          cmp         dword ptr [ebp-14h],2
00401132 74 25                je          $L7373+44h (00401159)
00401134 83 7D EC 03          cmp         dword ptr [ebp-14h],3
00401138 74 28                je          $L7373+4Dh (00401162)
0040113A 83 7D EC 08          cmp         dword ptr [ebp-14h],8
0040113E 74 2B                je          $L7373+56h (0040116b)
00401140 EB 54                jmp         $L7373+81h (00401196)
00401142 83 7D EC 23          cmp         dword ptr [ebp-14h],23h
00401146 74 35                je          $L7373+68h (0040117d)
00401148 83 7D EC 25          cmp         dword ptr [ebp-14h],25h
0040114C 74 38                je          $L7373+71h (00401186)
0040114E 81 7D EC 9A 02 00 00 cmp         dword ptr [ebp-14h],29Ah
00401155 74 38                je          $L7373+7Ah (0040118f)
00401157 EB 3D                jmp         $L7373+81h (00401196)
105:      case 2:j=1;break;
00401159 C7 45 F8 01 00 00 00 mov         dword ptr [ebp-8],1
00401160 EB 34                jmp         $L7373+81h (00401196)
106:      case 3:j=2;break;
00401162 C7 45 F8 02 00 00 00 mov         dword ptr [ebp-8],2
00401169 EB 2B                jmp         $L7373+81h (00401196)
107:      case 8:j=3;break;
0040116B C7 45 F8 03 00 00 00 mov         dword ptr [ebp-8],3
00401172 EB 22                jmp         $L7373+81h (00401196)
108:      case 10:j=4;break;
00401174 C7 45 F8 04 00 00 00 mov         dword ptr [ebp-8],4
0040117B EB 19                jmp         $L7373+81h (00401196)
109:      case 35:j=5;break;
0040117D C7 45 F8 05 00 00 00 mov         dword ptr [ebp-8],5
00401184 EB 10                jmp         $L7373+81h (00401196)
110:      case 37:j=6;break;
00401186 C7 45 F8 06 00 00 00 mov         dword ptr [ebp-8],6
0040118D EB 07                jmp         $L7373+81h (00401196)
111:      case 666:j=7;break;
0040118F C7 45 F8 07 00 00 00 mov         dword ptr [ebp-8],7


*/
				}

return 0;
}