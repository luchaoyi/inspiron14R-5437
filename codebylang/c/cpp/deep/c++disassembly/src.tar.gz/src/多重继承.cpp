#include<iostream>

using namespace std;

class CSofa
{
public:
	CSofa()
	{
		m_nColor = 2;
	}

	virtual ~CSofa()
	{
		cout<<"~CSofa"<<endl;
	}
	virtual GetColor()
	{
		return m_nColor;
	}
	virtual int SitDown()
	{
		cout<<"Sit down sofa"<<endl;
		return 0;
	}
protected:
	int m_nColor;
};

class CBed
{
public:
	CBed()
	{
		m_nLength = 4;
		m_nWidth = 5;
	}

	virtual ~CBed()
	{
		cout<<"~CBed"<<endl;
	}
	virtual GetArea()
	{
		return m_nLength * m_nWidth;
	}

	virtual int Sleep()
	{
		cout<<"sleep in bed"<<endl;

		return 0;
	}
protected:
	int m_nLength;
	int m_nWidth;
};

class CSofaBed:public CSofa ,public CBed
{
public:
	CSofaBed()
	{
		m_nHeight =6;
	}

	virtual ~CSofaBed()
	{
		cout<<"~CSofaBed"<<endl;
	}
	virtual int SitDown()
	{
		cout<<"Sit down sofabed"<<endl;
		return 0;
	}
		virtual int Sleep()
	{
		cout<<"sleep in sofabed"<<endl;
		return 0;
	}
protected:
	int m_nHeight;
};

void main()
{
	CSofaBed csb;
}


/*0040129E 59                   pop         ecx
0040129F 89 4D F0             mov         dword ptr [ebp-10h],ecx
004012A2 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
004012A5 E8 23 FE FF FF       call        @ILT+200(CSofa::CSofa) (004010cd)
004012AA C7 45 FC 00 00 00 00 mov         dword ptr [ebp-4],0
004012B1 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
004012B4 83 C1 08             add         ecx,8; 
004012B7 E8 34 FE FF FF       call        @ILT+235(CBed::CBed) (004010f0)
004012BC 8B 45 F0             mov         eax,dword ptr [ebp-10h]
004012BF C7 00 2C 20 43 00    mov         dword ptr [eax],offset CSofaBed::`vftable' (0043202c)���ָ��1
004012C5 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
004012C8 C7 41 08 1C 20 43 00 mov         dword ptr [ecx+8],offset CSofaBed::`vftable' (0043201c)���ָ��2
�̳����������
*/