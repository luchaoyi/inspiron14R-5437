#include<iostream>

class A
{
public:
	virtual void Show()=0;
};

class B: public A
{
public:
	virtual void Show()
	{
		printf("���������\n");
	}
};

void main()
{
	B b;
	b.Show();

}

/*
A::A 
00401169 59                   pop         ecx
0040116A 89 4D FC             mov         dword ptr [ebp-4],ecx
0040116D 8B 45 FC             mov         eax,dword ptr [ebp-4]
00401170 C7 00 30 10 43 00    mov         dword ptr [eax],offset A::`vftable' (00431030)//�������������д_purecall
00401176 8B 45 FC             mov         eax,dword ptr [ebp-4]

*/