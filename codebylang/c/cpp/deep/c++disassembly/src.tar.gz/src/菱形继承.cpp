#include<iostream>
#include<stdio.h>
using namespace std;

class CFurniture
{
public:
	CFurniture()
	{
		m_nPrice = 0;
	}

	virtual ~CFurniture()
	{
		printf("~CFurniture\n");
	}
	virtual int GetPrice()
	{
		return m_nPrice;
	}
protected:
	int m_nPrice;
};

class CSofa : virtual public CFurniture
{
public:
	CSofa()
	{
		m_nPrice = 1;
		m_nColor = 1;
	}

	virtual ~CSofa()
	{
		printf("~CSofa\n");
	}
		virtual GetColor()
	{
		return m_nColor;
	}
	virtual int SitDown()
	{
		cout<<"Sit down sofa"<<endl;
		return 0;
	}
protected:
	int m_nColor;
};

class CBed :virtual public CFurniture
{
public:
	CBed()
	{
		m_nPrice = 3;
		m_nLength = 4;
		m_nWidth = 5;
	}
	virtual ~CBed()
	{ 
		printf("~Virtual ~CBed\n");
	}

	virtual int GetArea()
	{
		return m_nLength * m_nWidth;
	}

	virtual int Sleep()
	{
		return printf("go to sleep\n");
	}

protected:
	int m_nLength;
	int m_nWidth;
};

class CSofaBed : public CSofa, public CBed
{
public:
	CSofaBed()
	{
		m_nHeight = 6 ;

	}

virtual ~CSofaBed()
{
	 printf("~CSofaBed\n");

} 
	virtual int Sleep()
	{
		return printf("go to sleep\n");
	}
		virtual int SitDown()
	{
		cout<<"Sit down sofa"<<endl;
		return 0;
	}
protected:
	int m_nHeight;
};

int main()
{
	CSofaBed sb;
	CFurniture *pFurniture =&sb;
	CSofa *pSofa =&sb;
	CSofa *pBed =&sb;


}
/*09:      CSofaBed sb;
00401278 6A 01                push        1 �Ƿ����游���־ 1���� 0������
0040127A 8D 4D D8             lea         ecx,[ebp-28h] 
0040127D E8 92 FD FF FF       call        @ILT+15(CSofaBed::CSofaBed) (00401014)
110:      CFurniture *pFurniture =&sb;
00401282 8D 45 D8             lea         eax,[ebp-28h]
00401285 85 C0                test        eax,eax
00401287 75 09                jne         main+32h (00401292)
00401289 C7 45 C8 00 00 00 00 mov         dword ptr [ebp-38h],0
00401290 EB 0D                jmp         main+3Fh (0040129f)
00401292 8B 4D DC             mov         ecx,dword ptr [ebp-24h]
00401295 8B 51 04             mov         edx,dword ptr [ecx+4]
00401298 8D 44 15 DC          lea         eax,[ebp+edx-24h]
0040129C 89 45 C8             mov         dword ptr [ebp-38h],eax
0040129F 8B 4D C8             mov         ecx,dword ptr [ebp-38h]
004012A2 89 4D D4             mov         dword ptr [ebp-2Ch],ecx
111:      CSofa *pSofa =&sb;
004012A5 8D 55 D8             lea         edx,[ebp-28h]
004012A8 89 55 D0             mov         dword ptr [ebp-30h],edx
112:      CSofa *pBed =&sb;
004012AB 8D 45 D8             lea         eax,[ebp-28h]
004012AE 89 45 CC             mov         dword ptr [ebp-34h],eax
113:  }
004012B1 8D 4D D8             lea         ecx,[ebp-28h]
004012B4 E8 60 FD FF FF       call        @ILT+20(CSofaBed::`vbase destructor') (00401019)
*/



/*83:       CSofaBed()

0040131E 59                   pop         ecx 
0040131F 89 4D F0             mov         dword ptr [ebp-10h],ecx
00401322 C7 45 EC 00 00 00 00 mov         dword ptr [ebp-14h],0
00401329 83 7D 08 00          cmp         dword ptr [ebp+8],0   �������ж�
0040132D 74 2F                je          CSofaBed::CSofaBed+6Eh (0040135e)
0040132F 8B 45 F0             mov         eax,dword ptr [ebp-10h]
00401332 C7 40 04 4C 30 43 00 mov         dword ptr [eax+4],offset CSofaBed::`vbtable' (0043304c)
00401339 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
0040133C C7 41 10 40 30 43 00 mov         dword ptr [ecx+10h],offset CSofaBed::`vbtable' (00433040)
00401343 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
00401346 83 C1 20             add         ecx,20h

00401349 E8 16 FD FF FF       call        @ILT+95(CFurniture::CFurniture) (00401064)
0040134E 8B 55 EC             mov         edx,dword ptr [ebp-14h]
00401351 83 CA 01             or          edx,1 ��������1
00401354 89 55 EC             mov         dword ptr [ebp-14h],edx
00401357 C7 45 FC 00 00 00 00 mov         dword ptr [ebp-4],0
0040135E 6A 00                push        0
00401360 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
00401363 E8 88 FD FF FF       call        @ILT+235(CSofa::CSofa) (004010f0) 
00401368 C7 45 FC 01 00 00 00 mov         dword ptr [ebp-4],1
0040136F 6A 00                push        0
00401371 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
00401374 83 C1 0C             add         ecx,0Ch
00401377 E8 92 FD FF FF       call        @ILT+265(CBed::CBed) (0040110e)
0040137C 8B 45 F0             mov         eax,dword ptr [ebp-10h]
0040137F C7 00 34 30 43 00    mov         dword ptr [eax],offset CSofaBed::`vftable' (00433034)
00401385 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
00401388 C7 41 0C 28 30 43 00 mov         dword ptr [ecx+0Ch],offset CSofaBed::`vftable' (00433028)
0040138F 8B 55 F0             mov         edx,dword ptr [ebp-10h]
00401392 8B 42 04             mov         eax,dword ptr [edx+4]
00401395 8B 48 04             mov         ecx,dword ptr [eax+4]
00401398 8B 55 F0             mov         edx,dword ptr [ebp-10h]
0040139B C7 44 0A 04 1C 30 43 mov         dword ptr [edx+ecx+4],offset CSofaBed::`vftable' (0043301c)
*/

// �ù����Ƿ�ֹ�ع�
