#include<stdio.h>
class CInit
{
public:
	CInit()
	{
		m_n=0;
	}
	int m_n;
};
class CBase
{
public:
	CBase()
	{
		printf("CBase\n");
	}
	~CBase()
	{
		printf("~CBase\n");
	}
	void SetNumber(int n)
	{
		m_nBase=n;
	}
	int GetNumber()
	{
		return m_nBase;
	}
public:
	int m_nBase;
};

class CDerive:public CBase
{
public:
	CDerive():m_nDervie(1)
	{
		printf("��ʼ��\n");
	}
	CInit m_I;
	int m_nDervie;
};


int main()
{
	CDerive d;
}

/*004010CE 59                   pop         ecx
004010CF 89 4D F0             mov         dword ptr [ebp-10h],ecx
004010D2 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
004010D5 E8 44 FF FF FF       call        @ILT+25(CBase::CBase) (0040101e)
���ø��๹�캯��
004010DA C7 45 FC 00 00 00 00 mov         dword ptr [ebp-4],0 �����������

004010E1 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
004010E4 83 C1 04             add         ecx,4
004010E7 E8 19 FF FF FF       call        @ILT+0(CInit::CInit) (00401005)


��ʼ���б�
004010EC 8B 45 F0             mov         eax,dword ptr [ebp-10h]
004010EF C7 40 08 01 00 00 00 mov         dword ptr [eax+8],1


39:           printf("��ʼ��\n");
004010F6 68 1C 50 42 00       push        offset string "\xb3\xf5\xca\xbc\xbb\xaf\n" (0042501c)
004010FB E8 C0 01 00 00       call        printf (004012c0)
00401100 83 C4 04             add         esp,4
*/