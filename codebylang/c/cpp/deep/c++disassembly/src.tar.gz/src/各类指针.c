#include<stdio.h>

int main()
{
	int nVar=0x12345678;
	int *pnVar = &nVar;
	char*pcVar=(char*)&nVar;
	printf("%08x\n",*pnVar);//*int dword ptr
	printf("%08x\n",*pcVar);//*char  byte ptr
	return 0;
	

}
/*int nVar=0x12345678;
00401028   mov         dword ptr [ebp-4],12345678h
6:        int *pnVar = &nVar;
0040102F   lea         eax,[ebp-4]
00401032   mov         dword ptr [ebp-8],eax //ָ���ʵ�֣�lea����ֵ
7:        char*pcVar=(char*)&nVar;
00401035   lea         ecx,[ebp-4]
00401038   mov         dword ptr [ebp-0Ch],ecx
8:        printf("%08x\n",*pnVar);
0040103B   mov         edx,dword ptr [ebp-8]
0040103E   mov         eax,dword ptr [edx] //*int dword ptr
00401040   push        eax
00401041   push        offset string "%08x\n" (0042201c)
00401046   call        printf (00401090)
0040104B   add         esp,8
9:        printf("%08x\n",*pcVar);
0040104E   mov         ecx,dword ptr [ebp-0Ch]
00401051   movsx       edx,byte ptr [ecx]//*char  byte ptr
00401054   push        edx
00401055   push        offset string "%08x\n" (0042201c)
0040105A   call        printf (00401090)
0040105F   add         esp,8
*/