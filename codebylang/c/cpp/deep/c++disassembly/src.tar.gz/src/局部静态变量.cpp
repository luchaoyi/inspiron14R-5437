#include<stdio.h>

void ShowStatic(int n)
{
	static int a=n;
	/*
00401038 33 C0                xor         eax,eax
0040103A A0 4C 7C 42 00       mov         al,[`ShowStatic'::`2'::$S1 (00427c4c)]
0040103F 83 E0 01             and         eax,1
00401042 85 C0                test        eax,eax
00401044 75 18                jne         ShowStatic+3Eh (0040105e)
00401046 8A 0D 4C 7C 42 00    mov         cl,byte ptr [`ShowStatic'::`2'::$S1 (00427c4c)]
0040104C 80 C9 01             or          cl,1
0040104F 88 0D 4C 7C 42 00    mov         byte ptr [`ShowStatic'::`2'::$S1 (00427c4c)],cl
00401055 8B 55 08             mov         edx,dword ptr [ebp+8]
00401058 89 15 48 7C 42 00    mov         dword ptr [___decimal_point_length+0A9Ch (00427c48)],e
	�ֲ���̬�����б�־״̬λ����
	һ���ֽڿ��Ա���8���ֲ���̬������״̬
	�������Ʒ���
	*/
	
	printf("%d",a);
}
int main()
{
	 ShowStatic(6);
}
