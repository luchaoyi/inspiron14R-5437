#include<iostream>

using namespace std;

class CT
{
public:
	int m_i1;
	int m_i2;
};

void Show1(CT F)
{
	cout<<F.m_i1<<F.m_i2<<endl;

}

void Show2(CT& F)
{
	cout<<F.m_i1<<F.m_i2<<endl;

}\

void Show3(CT *F)
{
	cout<<F->m_i1<<F->m_i2<<endl;
	cout<<*(&F+4)<<*(&F+8)<<endl;
}


void main()
{
	CT a;
	a.m_i1=1;
	a.m_i2=2;

	Show1(a);
	Show2(a);
	Show3(&a);
	/*00401726 8B 45 FC             mov         eax,dword ptr [ebp-4]
00401729 50                   push        eax
0040172A 8B 4D F8             mov         ecx,dword ptr [ebp-8]
0040172D 51                   push        ecx
0040172E E8 43 FB FF FF       call        @ILT+625(Show1) (00401276)
00401733 83 C4 08             add         esp,8//������Ϊ����ʱ�Ὣ�������ݸ���һ�飬���������룬���ƶ��󣬲���ȫ��ǳ��������ڴ�й©
38:       Show2(a);
00401736 8D 55 F8             lea         edx,[ebp-8]
00401739 52                   push        edx
0040173A E8 57 F9 FF FF       call        @ILT+145(Show2) (00401096)
0040173F 83 C4 04             add         esp,4//����ַ��������ȫ
39:       Show3(&a);
00401742 8D 45 F8             lea         eax,[ebp-8]
00401745 50                   push        eax
00401746 E8 1D FA FF FF       call        @ILT+355(Show3) (00401168)
0040174B 83 C4 04             add         esp,4
*/
}

