#include<stdio.h>

void main()
{
	int a[]={1,2,3,4};
	int *p=a;
	//0040104A 8B 4D F0             mov         ecx,dword ptr [ebp-10h]
	//0040104D 51                   push        ecx
	printf("%d",a[0]);
	//040105B 8B 55 EC             mov         edx,dword ptr [ebp-14h]
	//0040105E 8B 02                mov         eax,dword ptr [edx]
    //								  push        eax
	//ָ������Ѱַ���±�һ�Σ��±�Ѱַ��
	printf("%d",*p);
}
