#include <stdio.h>
void print(int &i)
{
	printf("%d\n",i);

}
void pt(int *p)
{
	printf("%d",*p);
}
int main()
{
	int i=123456;
	int &t=i;
	int *p=&i;//���õı�����ָ��
	

	print(t);
	pt(p);

}
/*12:       int i=123456;
0040D778   mov         dword ptr [ebp-4],1E240h
13:       int &t=i;
0040D77F   lea         eax,[ebp-4]
0040D782   mov         dword ptr [ebp-8],eax
15:       int *p=&i;
0040D785   lea         ecx,[ebp-4]
0040D788   mov         dword ptr [ebp-0Ch],ecx
16:
17:
18:       print(t);
0040D78B   mov         edx,dword ptr [ebp-8]
0040D78E   push        edx
0040D78F   call        @ILT+0(print) (00401005)
0040D794   add         esp,4
19:       pt(p);
0040D797   mov         eax,dword ptr [ebp-0Ch]
0040D79A   push        eax
0040D79B   call        @ILT+10(pt) (0040100f)
0040D7A0   add         esp,4
2:    void print(int &i)
3:    {
00401020   push        ebp
00401021   mov         ebp,esp
00401023   sub         esp,40h
00401026   push        ebx
00401027   push        esi
00401028   push        edi
00401029   lea         edi,[ebp-40h]//ȡ��ַ
0040102C   mov         ecx,10h
00401031   mov         eax,0CCCCCCCCh
00401036   rep stos    dword ptr [edi]//����ַȡֵ
4:        printf("%d\n",i);
00401038   mov         eax,dword ptr [ebp+8]
0040103B   mov         ecx,dword ptr [eax]
0040103D   push        ecx
0040103E   push        offset string "%d\n" (0042201c)
00401043   call        printf (004010d0)
00401048   add         esp,8
5:    }
0040104B   pop         edi
0040104C   pop         esi
0040104D   pop         ebx
0040104E   add         esp,40h
00401051   cmp         ebp,esp
00401053   call        __chkesp (00401150)
00401058   mov         esp,ebp
0040105A   pop         ebp
0040105B   ret
6:    void pt(int *p)
7:    {
00401070   push        ebp
00401071   mov         ebp,esp
00401073   sub         esp,40h
00401076   push        ebx
00401077   push        esi
00401078   push        edi
00401079   lea         edi,[ebp-40h]
0040107C   mov         ecx,10h
00401081   mov         eax,0CCCCCCCCh
00401086   rep stos    dword ptr [edi]
8:        printf("%d",*p);
00401088   mov         eax,dword ptr [ebp+8]
0040108B   mov         ecx,dword ptr [eax]
0040108D   push        ecx
0040108E   push        offset string "%d" (0042212c)
00401093   call        printf (004010d0)
00401098   add         esp,8
9:    }

*/
