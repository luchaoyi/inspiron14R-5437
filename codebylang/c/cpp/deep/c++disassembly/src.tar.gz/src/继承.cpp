#include<stdio.h>

class CBase
{
public:
	CBase()
	{
		printf("CBase\n");
	}
	~CBase()
	{
		printf("~CBase\n");
	}
	void SetNumber(int n)
	{
		m_nBase=n;
	}
	int GetNumber()
	{
		return m_nBase;
	}
public:
	int m_nBase;
};

class CDerive:public CBase
{
public:
	void ShowNumber(int n)
	{
		SetNumber(n);
		m_nDervie = n+1;
		printf("%d\n",GetNumber());
		printf("%d\n",m_nDervie);

	}
public:
	int m_nDervie;
};


int main()
{
	CDerive d;
	d.ShowNumber(5);
	/*44:       CDerive d;
0040108D 8D 4D EC             lea         ecx,[ebp-14h]ȡ�����յ�ַ��Ϊthisָ��
00401090 E8 84 FF FF FF       call        @ILT+20(CDerive::CDerive) (00401019) ������Ĭ�Ϲ��캯��
00401095 C7 45 FC 00 00 00 00 mov         dword ptr [ebp-4],0
45:       d.ShowNumber(5);
0040109C 6A 05                push        5
0040109E 8D 4D EC             lea         ecx,[ebp-14h]����thisָ����ó�Ա����
004010A1 E8 69 FF FF FF       call        @ILT+10(CDerive::ShowNumber) (0040100f)
004010A6 C7 45 FC FF FF FF FF mov         dword ptr [ebp-4],0FFFFFFFFh
004010AD 8D 4D EC             lea         ecx,[ebp-14h]
004010B0 E8 69 FF FF FF       call        @ILT+25(CDerive::~CDerive) (0040101e)  ������Ĭ����������

*/

	return 0;
	
}


/*CDerive::CDerive:



00401219 59                   pop         ecx ��ԭthisָ��
0040121A 89 4D FC             mov         dword ptr [ebp-4],ecx
0040121D 8B 4D FC             mov         ecx,dword ptr [ebp-4] ����������׵�ַΪthisָ����ø��๹�캯��
00401220 E8 03 FE FF FF       call        @ILT+35(CBase::CBase) (00401028)
00401225 8B 45 FC             mov         eax,dword ptr [ebp-4]


 CDerive::~CDerive:

004012B9 59                   pop         ecx
004012BA 89 4D FC             mov         dword ptr [ebp-4],ecx
004012BD 8B 4D FC             mov         ecx,dword ptr [ebp-4]
004012C0 E8 45 FD FF FF       call        @ILT+5(CBase::~CBase) (0040100a)
*/
	
