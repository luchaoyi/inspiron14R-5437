#include<stdio.h>

int main()
{
	int i=0;
	do
	{
		i++;
	}while(i<5);
//һ����ת Ч�����
	/*
		do_begin:
		...
		jxx do_begin
	*/
	while(i<20)
	{
		i++;
	}
/*

  ������ת   while_begin:	
				jxx  while_end
				...
				jmp while_begin
			while_end
	*/
	for(i;i<30;i++)
	{
		printf("%d",i);
	}

/*
	������ת���
	����ֵ
	jmp ��ѭ���ж�

	step++

	ѭ���ж���
	jxx  end
	������

  jmp step++����

	*/








	/*      do
7:        {
8:            i++;
0040102F 8B 45 FC             mov         eax,dword ptr [ebp-4]
00401032 83 C0 01             add         eax,1
00401035 89 45 FC             mov         dword ptr [ebp-4],eax 																		
9:        }while(i<5);
00401038 83 7D FC 05          cmp         dword ptr [ebp-4],5
0040103C 7C F1                jl          main+1Fh (0040102f)
10:
11:       while(i<20)
0040103E 83 7D FC 14          cmp         dword ptr [ebp-4],14h
00401042 7D 0B                jge         main+3Fh (0040104f)
12:       {
13:           i++;
00401044 8B 4D FC             mov         ecx,dword ptr [ebp-4]
00401047 83 C1 01             add         ecx,1
0040104A 89 4D FC             mov         dword ptr [ebp-4],ecx
14:       }
0040104D EB EF                jmp         main+2Eh (0040103e)
1       for(i;i<30;i++)
0040104F EB 09                jmp         main+4Ah (0040105a)
00401051 8B 55 FC             mov         edx,dword ptr [ebp-4]
00401054 83 C2 01             add         edx,1
00401057 89 55 FC             mov         dword ptr [ebp-4],edx
0040105A 83 7D FC 1E          cmp         dword ptr [ebp-4],1Eh
0040105E 7D 13                jge         main+63h (00401073)
29:       {
30:           printf("%d",i);
00401060 8B 45 FC             mov         eax,dword ptr [ebp-4]
00401063 50                   push        eax
00401064 68 1C 20 42 00       push        offset string "%d" (0042201c)
00401069 E8 42 00 00 00       call        printf (004010b0)
0040106E 83 C4 08             add         esp,8
31:       }
00401071 EB DE                jmp         main+41h (00401051)

*/
}