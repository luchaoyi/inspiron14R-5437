#include<iostream>
using namespace std;
class CNumber
{
public:
	CNumber()
	{
		m_nOne = 1;
		m_nTwo = 2;
	}
	int GetNumberOne()
	{
		return m_nOne;
	}
	int GetNumberTwo()
	{
		return m_nTwo;
	}
	void PrintAddress()
	{
		cout<<this<<endl;//���thisָ���ַ
	}
	~CNumber()
	{
		cout<<"hello"<<endl;
	}
private:
	int m_nOne;
	int m_nTwo;
};

void main()
{
	CNumber Number;

	cout<<Number.GetNumberOne()<<endl;
	cout<<Number.GetNumberTwo()<<endl;
	cout<<&Number<<endl;
	Number.PrintAddress();//thisָ��ָ��ǰ��

						  
						  
/*
7:        {
8:            m_nOne = 1;
0040167D 8B 45 FC             mov         eax,dword ptr [ebp-4] //eax��������׵�ַ��thisָ��
00401680 C7 00 01 00 00 00    mov         dword ptr [eax],1
9:            m_nTwo = 2;
00401686 8B 4D FC             mov         ecx,dword ptr [ebp-4]
00401689 C7 41 04 02 00 00 00 mov         dword ptr [ecx+4],2  
10:       }
*/
}