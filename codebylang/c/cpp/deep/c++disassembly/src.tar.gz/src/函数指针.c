#include<stdio.h>

int t(int a)
{
	return a;
}
int main()
{
	int (*p)()=t;
	p(1);
	t(1);
/*9:        int (*p)()=t;
00401068 C7 45 FC 05 10 40 00 mov         dword ptr [ebp-4],offset @ILT+0(_t) (00401005)//ȡ������ַ����[ebp-4]
10:       p(1);
0040106F 8B F4                mov         esi,esp
00401071 6A 01                push        1
00401073 FF 55 FC             call        dword ptr [ebp-4]//��ӵ���
00401076 83 C4 04             add         esp,4
00401079 3B F4                cmp         esi,esp
0040107B E8 30 00 00 00       call        __chkesp (004010b0)
11:       t(1);
00401080 6A 01                push        1
00401082 E8 7E FF FF FF       call        @ILT+0(_t) (00401005)//ֱ�ӵ���
00401087 83 C4 04             add         esp,4
*/

}