#include<stdio.h>

int _stdcall t1(int a,int b)
{
	return a+b;
}
int _cdecl t2(int a,int b)
{
		return a+b;

}
int _fastcall t3(int a,int b)
{
	return a+b;
}
int main()
{
	int a=1,b=2;
	t1(a,b);
	t2(a,b);
	t3(a,b);
	/*18:       int a=1,b=2;
004010E8 C7 45 FC 01 00 00 00 mov         dword ptr [ebp-4],1
004010EF C7 45 F8 02 00 00 00 mov         dword ptr [ebp-8],2
19:       t1(a,b);
004010F6 8B 45 F8             mov         eax,dword ptr [ebp-8]
004010F9 50                   push        eax
004010FA 8B 4D FC             mov         ecx,dword ptr [ebp-4]
004010FD 51                   push        ecx
004010FE E8 0C FF FF FF       call        @ILT+10(_t1@8) (0040100f)//������ƽ���ջ
20:       t2(a,b);
00401103 8B 55 F8             mov         edx,dword ptr [ebp-8]
00401106 52                   push        edx
00401107 8B 45 FC             mov         eax,dword ptr [ebp-4]
0040110A 50                   push        eax
0040110B E8 FA FE FF FF       call        @ILT+5(_t2) (0040100a)
00401110 83 C4 08             add         esp,8//��������ƽ��ջ
21:       t3(a,b);
00401113 8B 55 F8             mov         edx,dword ptr [ebp-8]
00401116 8B 4D FC             mov         ecx,dword ptr [ebp-4]
00401119 E8 F6 FE FF FF       call        @ILT+15(@t3@8) (00401014)//����ʹ�üĴ������Σ����Ĵ����������ޣ�����ջ���Σ�
22:   }
*/
}