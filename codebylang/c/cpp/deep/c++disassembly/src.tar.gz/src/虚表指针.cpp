#include<stdio.h>


class CPerson
{
public:
	CPerson(){}
	virtual ~CPerson(){}
	virtual void ShowSpeak(){}
};

class CChinese:public CPerson
{
public:
	CChinese(){}
	virtual ~CChinese(){}
	virtual void ShowSpeak()
	{
		printf("Speak Chinese\n");
	}
};


class CAmerican:public CPerson
{
public:
	virtual ~CAmerican(){}
	CAmerican(){}
	virtual void ShowSpeak()
	{
		printf("Speak American\n");
	}
};



class CGerman:public CPerson
{
public:
	CGerman(){}
	virtual ~CGerman(){}
	virtual void ShowSpeak()
	{
		printf("Speak German\n");
	}
};

void Speak(CPerson &pPerson)
{
	pPerson.ShowSpeak();
}

void main()
{
	CChinese c;
	CAmerican a;
	CGerman g;
	

	Speak(c);
	Speak(a);
	Speak(g);

}

/*void Speak(CPerson &pPerson)
00401108 8B 45 08             mov         eax,dword ptr [ebp+8]//��ȡpPerson��ֵ
0040110B 8B 10                mov         edx,dword ptr [eax]//ȡ����׵�ַ
0040110D 8B F4                mov         esi,esp
0040110F 8B 4D 08             mov         ecx,dword ptr [ebp+8]//����thisָ��

 edx �����һ������������������ ����[edx+4] ShowSpeak()�ĵ�ַ
00401112 FF 52 04             call        dword ptr [edx+4]
00401115 3B F4                cmp         esi,esp
00401117 E8 84 06 00 00       call        __chkesp (004017a0)*/