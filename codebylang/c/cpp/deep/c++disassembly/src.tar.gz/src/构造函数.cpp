#include<iostream>

using namespace std;

class CNumber
{
public:
	CNumber()
	{
		m_n=1;
/*00401109 59                   pop         ecx				//ecx������thisָ��
0040110A 89 4D FC             mov         dword ptr [ebp-4],ecx
9:        {
10:           m_n=1;
0040110D 8B 45 FC             mov         eax,dword ptr [ebp-4]
00401110 C7 00 01 00 00 00    mov         dword ptr [eax],1
11:       }
00401116 8B 45 FC             mov         eax,dword ptr [ebp-4]//����thisָ��
00401119 5F                   pop         edi
0040111A 5E                   pop         esi
0040111B 5B                   pop         ebx
0040111C 8B E5                mov         esp,ebp
0040111E 5D                   pop         ebp
0040111F C3                   ret
*/

	}
	int m_n;
};

void main()
{
	CNumber N;//�ֲ�����
	CNumber *pN = new CNumber;//�Ѷ���
	pN->m_n=2;
	/*34:       CNumber *pN = new CNumber;
00401065 6A 04                push        4//ѹ�����С�����ڶ��ڴ�����
00401067 E8 94 71 00 00       call        operator new (00408200)
0040106C 83 C4 04             add         esp,4
0040106F 89 45 E4             mov         dword ptr [ebp-1Ch],eax//��ʱ���������ַ
00401072 C7 45 FC 00 00 00 00 mov         dword ptr [ebp-4],0//��������ѿռ����
00401079 83 7D E4 00          cmp         dword ptr [ebp-1Ch],0//����Ƿ�ΪNULL,����ɹ���
0040107D 74 0D                je          main+5Ch (0040108c);ʧ��������
0040107F 8B 4D E4             mov         ecx,dword ptr [ebp-1Ch]����ɹ�����ַ����ecx
00401082 E8 7E FF FF FF       call        @ILT+0(CNumber::CNumber) (00401005)
00401087 89 45 E0             mov         dword ptr [ebp-20h],eax
0040108A EB 07                jmp         main+63h (00401093)
0040108C C7 45 E0 00 00 00 00 mov         dword ptr [ebp-20h],0
00401093 8B 45 E0             mov         eax,dword ptr [ebp-20h]
00401096 89 45 E8             mov         dword ptr [ebp-18h],eax
00401099 C7 45 FC FF FF FF FF mov         dword ptr [ebp-4],0FFFFFFFFh
004010A0 8B 4D E8             mov         ecx,dword ptr [ebp-18h]
004010A3 89 4D EC             mov         dword ptr [ebp-14h],ecx
35:       pN->m_n=2;
004010A6 8B 55 EC             mov         edx,dword ptr [ebp-14h]
004010A9 C7 02 02 00 00 00    mov         dword ptr [edx],2
*/
}
