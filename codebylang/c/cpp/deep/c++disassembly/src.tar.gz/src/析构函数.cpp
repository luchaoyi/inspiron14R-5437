#include<iostream>

using namespace std;

class CNumber
{
public:
	CNumber()
	{
		m_n=1;
	}
	~CNumber()
	{
		printf("~CNumber\n");
	}
	int m_n;
};

void main()
{
	CNumber *pArray = new CNumber[2];

	if(pArray != NULL)
	{
		delete[] pArray;
		pArray = NULL;
	}
}

/*0040107D 6A 0C                push        0Ch//�ѵ�ַ����ʱ���׵�ַ��4�ֽ����ڱ�������ܸ���8+4=12
0040107F E8 AC 73 00 00       call        operator new (00408430)
00401084 83 C4 04             add         esp,4
00401087 89 45 E8             mov         dword ptr [ebp-18h],eax//eax ����ѿռ���ַ
0040108A C7 45 FC 00 00 00 00 mov         dword ptr [ebp-4],0//����ѿռ�Ĵ���
00401091 83 7D E8 00          cmp         dword ptr [ebp-18h],0//����Ƿ�ΪNULL,�Ƿ�����ɹ�
00401095 74 2E                je          main+75h (004010c5)
00401097 68 1E 10 40 00       push        offset @ILT+25(CNumber::~CNumber) (0040101e)//ѹ����������ָ��
0040109C 68 0A 10 40 00       push        offset @ILT+5(CNumber::CNumber) (0040100a)//ѹ�빹�캯��ָ��
004010A1 8B 45 E8             mov         eax,dword ptr [ebp-18h]
004010A4 C7 00 02 00 00 00    mov         dword ptr [eax],2//�׵�ַ4�ֽ�Ϊ������� set 2;
004010AA 6A 02                push        2//ѹ��������
004010AC 6A 04                push        4//ѹ������С
004010AE 8B 4D E8             mov         ecx,dword ptr [ebp-18h]
004010B1 83 C1 04             add         ecx,4
004010B4 51                   push        ecx//ecx=ecx+4�������Ⱥ��ַ�ĸ��ֽڣ�����һ�������ַѹջ
004010B5 E8 D6 72 00 00       call        `eh vector constructor iterator' (00408390)//���ù�����������������������ù��캯��
004010BA 8B 55 E8             mov         edx,dword ptr [ebp-18h]
004010BD 83 C2 04             add         edx,4
004010C0 89 55 DC             mov         dword ptr [ebp-24h],edx�������һ��������ַ
004010C3 EB 07                jmp         main+7Ch (004010cc)
004010C5 C7 45 DC 00 00 00 00 mov         dword ptr [ebp-24h],0//����ʧ�ܴ��� ָ��NULL
004010CC 8B 45 DC             mov         eax,dword ptr [ebp-24h]
004010CF 89 45 EC             mov         dword ptr [ebp-14h],eax
004010D2 C7 45 FC FF FF FF FF mov         dword ptr [ebp-4],0FFFFFFFFh//���������Ϊ-1����P,V�ź���˼�룩
004010D9 8B 4D EC             mov         ecx,dword ptr [ebp-14h]
004010DC 89 4D F0             mov         dword ptr [ebp-10h],ecx//pArray
22:       if(pArray != NULL)
004010DF 83 7D F0 00          cmp         dword ptr [ebp-10h],0
004010E3 74 2F                je          main+0C4h (00401114)
23:       {
24:           delete[] pArray;
004010E5 8B 55 F0             mov         edx,dword ptr [ebp-10h]
004010E8 89 55 E0             mov         dword ptr [ebp-20h],edx
004010EB 8B 45 E0             mov         eax,dword ptr [ebp-20h]
004010EE 89 45 E4             mov         dword ptr [ebp-1Ch],eax
004010F1 83 7D E4 00          cmp         dword ptr [ebp-1Ch],0
004010F5 74 0F                je          main+0B6h (00401106)
004010F7 6A 03                push        3//delete ��־λ
004010F9 8B 4D E4             mov         ecx,dword ptr [ebp-1Ch]
004010FC E8 04 FF FF FF       call        @ILT+0(CNumber::`vector deleting destructor') (00401005)//�ͷŶѶ�����
00401101 89 45 D8             mov         dword ptr [ebp-28h],eax
00401104 EB 07                jmp         main+0BDh (0040110d)
00401106 C7 45 D8 00 00 00 00 mov         dword ptr [ebp-28h],0
25:           pArray = NULL;
0040110D C7 45 F0 00 00 00 00 mov         dword ptr [ebp-10h],0
26:       }
---------------------------------------------------------------------------------------------
�Ѷ����ͷź�������
CNumber::`vector deleting destructor':
00401200 55                   push        ebp
00401201 8B EC                mov         ebp,esp
00401203 83 EC 44             sub         esp,44h
00401206 53                   push        ebx
00401207 56                   push        esi
00401208 57                   push        edi
00401209 51                   push        ecx
0040120A 8D 7D BC             lea         edi,[ebp-44h]
0040120D B9 11 00 00 00       mov         ecx,11h
00401212 B8 CC CC CC CC       mov         eax,0CCCCCCCCh
00401217 F3 AB                rep stos    dword ptr [edi]

00401219 59                   pop         ecx
0040121A 89 4D FC             mov         dword ptr [ebp-4],ecx
0040121D 8B 45 08             mov         eax,dword ptr [ebp+8]
00401220 83 E0 02             and         eax,2
00401223 85 C0                test        eax,eax
00401225 74 38                je          CNumber::`vector deleting destructor'+5Fh (0040125f)
00401227 68 1E 10 40 00       push        offset @ILT+25(CNumber::~CNumber) (0040101e)//ѹ����������
0040122C 8B 4D FC             mov         ecx,dword ptr [ebp-4]
0040122F 8B 51 FC             mov         edx,dword ptr [ecx-4]
00401232 52                   push        edx
00401233 6A 04                push        4
00401235 8B 45 FC             mov         eax,dword ptr [ebp-4]
00401238 50                   push        eax
00401239 E8 A2 77 00 00       call        `eh vector destructor iterator' (004089e0)//����������������
0040123E 8B 4D 08             mov         ecx,dword ptr [ebp+8]
00401241 83 E1 01             and         ecx,1
00401244 85 C9                test        ecx,ecx
00401246 74 0F                je          CNumber::`vector deleting destructor'+57h (00401257)
00401248 8B 55 FC             mov         edx,dword ptr [ebp-4]
0040124B 83 EA 04             sub         edx,4
0040124E 52                   push        edx
0040124F E8 9C 03 00 00       call        operator delete (004015f0)
*/

//����Ѷ��� �������͹���ͨ�������������