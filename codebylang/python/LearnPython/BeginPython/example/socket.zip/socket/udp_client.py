#!coding:utf8

import socket

target_host="127.0.0.1"
target_port=80



client=socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
#udp不需要connect，面向无连接
client.sendto("AABBCC",(target_host,target_port))
data,addr=client.recvfrom(4096)
print data





